--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.3
-- Dumped by pg_dump version 9.5.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP INDEX public.pokemon_info_pokemon_id_idx;
ALTER TABLE ONLY public.pokemon_info DROP CONSTRAINT pokemon_info_pkey;
DROP TABLE public.pokemon_info;
SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: pokemon_info; Type: TABLE; Schema: public; Owner: pokemon_go_role
--

CREATE TABLE pokemon_info (
    pokemon_id bigint NOT NULL,
    name text,
    classification text,
    type_1 text,
    type_2 text,
    weight double precision,
    height double precision
);


ALTER TABLE pokemon_info OWNER TO pokemon_go_role;

--
-- Data for Name: pokemon_info; Type: TABLE DATA; Schema: public; Owner: pokemon_go_role
--

COPY pokemon_info (pokemon_id, name, classification, type_1, type_2, weight, height) FROM stdin;
\.
COPY pokemon_info (pokemon_id, name, classification, type_1, type_2, weight, height) FROM '$$PATH$$/3411.dat';

--
-- Name: pokemon_info_pkey; Type: CONSTRAINT; Schema: public; Owner: pokemon_go_role
--

ALTER TABLE ONLY pokemon_info
    ADD CONSTRAINT pokemon_info_pkey PRIMARY KEY (pokemon_id);


--
-- Name: pokemon_info_pokemon_id_idx; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX pokemon_info_pokemon_id_idx ON pokemon_info USING btree (pokemon_id);


--
-- PostgreSQL database dump complete
--

