--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.3
-- Dumped by pg_dump version 9.5.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP TRIGGER create_timekey ON public.spotted_pokemon;
DROP TRIGGER create_datekey ON public.spotted_pokemon;
DROP TRIGGER compute_point_jittered ON public.spotted_pokemon;
DROP TRIGGER compute_point ON public.spotted_pokemon;
DROP INDEX public.time_dimension_time_key_idx;
DROP INDEX public.pokemon_id_index;
DROP INDEX public.point_index;
DROP INDEX public.name_index;
DROP INDEX public.longitude_jit_index;
DROP INDEX public.longitude_index;
DROP INDEX public.latitude_jit_index;
DROP INDEX public.latitude_index;
DROP INDEX public.jitter_index;
DROP INDEX public.date_dimension_date_key_idx;
ALTER TABLE ONLY public.time_dimension DROP CONSTRAINT time_dimension_pkey;
ALTER TABLE ONLY public.pokemon_info DROP CONSTRAINT pokemon_id_primary;
ALTER TABLE ONLY public.spotted_pokemon DROP CONSTRAINT id_primary_key;
ALTER TABLE ONLY public.date_dimension DROP CONSTRAINT date_dimension_pkey;
ALTER TABLE public.spotted_pokemon ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.time_dimension;
DROP SEQUENCE public.spotted_pokemon_id_seq;
DROP TABLE public.spotted_pokemon;
DROP TABLE public.pokemon_info;
DROP TABLE public.date_dimension;
DROP FUNCTION public.create_timekey_fn();
DROP FUNCTION public.create_point_from_lon_lat_jit();
DROP FUNCTION public.create_point_from_lon_lat();
DROP FUNCTION public.create_datekey_fn();
DROP EXTENSION postgis;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


SET search_path = public, pg_catalog;

--
-- Name: create_datekey_fn(); Type: FUNCTION; Schema: public; Owner: pokemon_go_role
--

CREATE FUNCTION create_datekey_fn() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  payload text;
BEGIN
    NEW.date_key = NULLIF(to_char(NEW.hidden_time_utc, 'YYYYMMDD'), '')::int;
    RETURN NEW;
END
$$;


ALTER FUNCTION public.create_datekey_fn() OWNER TO pokemon_go_role;

--
-- Name: create_point_from_lon_lat(); Type: FUNCTION; Schema: public; Owner: pokemon_go_role
--

CREATE FUNCTION create_point_from_lon_lat() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  payload text;
BEGIN
    NEW.geo_point = St_SetSRID(ST_MakePoint(NEW.longitude, NEW.latitude), 4326);
    RETURN NEW;
END
$$;


ALTER FUNCTION public.create_point_from_lon_lat() OWNER TO pokemon_go_role;

--
-- Name: create_point_from_lon_lat_jit(); Type: FUNCTION; Schema: public; Owner: pokemon_go_role
--

CREATE FUNCTION create_point_from_lon_lat_jit() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  payload text;
BEGIN
    NEW.geo_point_jittered = St_SetSRID(ST_MakePoint(NEW.longitude_jittered, NEW.latitude_jittered), 4326);
    RETURN NEW;
END
$$;


ALTER FUNCTION public.create_point_from_lon_lat_jit() OWNER TO pokemon_go_role;

--
-- Name: create_timekey_fn(); Type: FUNCTION; Schema: public; Owner: pokemon_go_role
--

CREATE FUNCTION create_timekey_fn() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  payload text;
BEGIN
    NEW.time_key = to_char(NEW.hidden_time_utc, 'MI')::int + (to_char(NEW.hidden_time_utc, 'HH24')::int * 60);
    RETURN NEW;
END
$$;


ALTER FUNCTION public.create_timekey_fn() OWNER TO pokemon_go_role;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: date_dimension; Type: TABLE; Schema: public; Owner: pokemon_go_role
--

CREATE TABLE date_dimension (
    date_key text NOT NULL,
    full_date timestamp without time zone,
    day_of_week bigint,
    day_of_week_name text,
    day_of_week_name_abbrev text,
    day_of_month bigint,
    day_number_overall bigint,
    weekday_flag text,
    week_number bigint,
    week_number_overall bigint,
    week_begin_date timestamp without time zone,
    week_begin_date_key text,
    month_number bigint,
    month_number_overall bigint,
    month text,
    month_abbrev text,
    quarter bigint,
    year text,
    year_month text,
    month_end_flag text
);


ALTER TABLE date_dimension OWNER TO pokemon_go_role;

--
-- Name: pokemon_info; Type: TABLE; Schema: public; Owner: pokemon_go_role
--

CREATE TABLE pokemon_info (
    pokemon_id smallint NOT NULL,
    name character varying(40),
    type character varying(40),
    rarity character varying(30)
);


ALTER TABLE pokemon_info OWNER TO pokemon_go_role;

--
-- Name: spotted_pokemon; Type: TABLE; Schema: public; Owner: pokemon_go_role
--

CREATE TABLE spotted_pokemon (
    id integer NOT NULL,
    name character varying(40) NOT NULL,
    encounter_id character varying(40),
    last_modified_time bigint,
    time_until_hidden_ms bigint,
    hidden_time_unix_s bigint,
    hidden_time_utc timestamp without time zone,
    spawnpoint_id character varying(20),
    longitude double precision,
    latitude double precision,
    pokemon_id smallint,
    time_key smallint,
    date_key integer,
    longitude_jittered double precision,
    latitude_jittered double precision,
    geo_point geometry,
    geo_point_jittered geometry
);


ALTER TABLE spotted_pokemon OWNER TO pokemon_go_role;

--
-- Name: spotted_pokemon_id_seq; Type: SEQUENCE; Schema: public; Owner: pokemon_go_role
--

CREATE SEQUENCE spotted_pokemon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE spotted_pokemon_id_seq OWNER TO pokemon_go_role;

--
-- Name: spotted_pokemon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pokemon_go_role
--

ALTER SEQUENCE spotted_pokemon_id_seq OWNED BY spotted_pokemon.id;


--
-- Name: time_dimension; Type: TABLE; Schema: public; Owner: pokemon_go_role
--

CREATE TABLE time_dimension (
    time_key bigint NOT NULL,
    time_label_24 text,
    time_label_12 text,
    time_interval_15min bigint,
    time_interval_30min bigint,
    time_interval_60min bigint,
    label_hh text,
    label_hh24 text,
    label_15min_24 text,
    label_30min_24 text,
    label_60min_24 text,
    label_15min_12 text,
    label_30min_12 text,
    label_60min_12 text
);


ALTER TABLE time_dimension OWNER TO pokemon_go_role;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: pokemon_go_role
--

ALTER TABLE ONLY spotted_pokemon ALTER COLUMN id SET DEFAULT nextval('spotted_pokemon_id_seq'::regclass);


--
-- Data for Name: date_dimension; Type: TABLE DATA; Schema: public; Owner: pokemon_go_role
--

COPY date_dimension (date_key, full_date, day_of_week, day_of_week_name, day_of_week_name_abbrev, day_of_month, day_number_overall, weekday_flag, week_number, week_number_overall, week_begin_date, week_begin_date_key, month_number, month_number_overall, month, month_abbrev, quarter, year, year_month, month_end_flag) FROM stdin;
\.
COPY date_dimension (date_key, full_date, day_of_week, day_of_week_name, day_of_week_name_abbrev, day_of_month, day_number_overall, weekday_flag, week_number, week_number_overall, week_begin_date, week_begin_date_key, month_number, month_number_overall, month, month_abbrev, quarter, year, year_month, month_end_flag) FROM '$$PATH$$/3459.dat';

--
-- Data for Name: pokemon_info; Type: TABLE DATA; Schema: public; Owner: pokemon_go_role
--

COPY pokemon_info (pokemon_id, name, type, rarity) FROM stdin;
\.
COPY pokemon_info (pokemon_id, name, type, rarity) FROM '$$PATH$$/3460.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: pokemon_go_role
--

COPY spatial_ref_sys  FROM stdin;
\.
COPY spatial_ref_sys  FROM '$$PATH$$/3314.dat';

--
-- Data for Name: spotted_pokemon; Type: TABLE DATA; Schema: public; Owner: pokemon_go_role
--

COPY spotted_pokemon (id, name, encounter_id, last_modified_time, time_until_hidden_ms, hidden_time_unix_s, hidden_time_utc, spawnpoint_id, longitude, latitude, pokemon_id, time_key, date_key, longitude_jittered, latitude_jittered, geo_point, geo_point_jittered) FROM stdin;
\.
COPY spotted_pokemon (id, name, encounter_id, last_modified_time, time_until_hidden_ms, hidden_time_unix_s, hidden_time_utc, spawnpoint_id, longitude, latitude, pokemon_id, time_key, date_key, longitude_jittered, latitude_jittered, geo_point, geo_point_jittered) FROM '$$PATH$$/3461.dat';

--
-- Name: spotted_pokemon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pokemon_go_role
--

SELECT pg_catalog.setval('spotted_pokemon_id_seq', 83, true);


--
-- Data for Name: time_dimension; Type: TABLE DATA; Schema: public; Owner: pokemon_go_role
--

COPY time_dimension (time_key, time_label_24, time_label_12, time_interval_15min, time_interval_30min, time_interval_60min, label_hh, label_hh24, label_15min_24, label_30min_24, label_60min_24, label_15min_12, label_30min_12, label_60min_12) FROM stdin;
\.
COPY time_dimension (time_key, time_label_24, time_label_12, time_interval_15min, time_interval_30min, time_interval_60min, label_hh, label_hh24, label_15min_24, label_30min_24, label_60min_24, label_15min_12, label_30min_12, label_60min_12) FROM '$$PATH$$/3463.dat';

--
-- Name: date_dimension_pkey; Type: CONSTRAINT; Schema: public; Owner: pokemon_go_role
--

ALTER TABLE ONLY date_dimension
    ADD CONSTRAINT date_dimension_pkey PRIMARY KEY (date_key);


--
-- Name: id_primary_key; Type: CONSTRAINT; Schema: public; Owner: pokemon_go_role
--

ALTER TABLE ONLY spotted_pokemon
    ADD CONSTRAINT id_primary_key PRIMARY KEY (id);


--
-- Name: pokemon_id_primary; Type: CONSTRAINT; Schema: public; Owner: pokemon_go_role
--

ALTER TABLE ONLY pokemon_info
    ADD CONSTRAINT pokemon_id_primary PRIMARY KEY (pokemon_id);


--
-- Name: time_dimension_pkey; Type: CONSTRAINT; Schema: public; Owner: pokemon_go_role
--

ALTER TABLE ONLY time_dimension
    ADD CONSTRAINT time_dimension_pkey PRIMARY KEY (time_key);


--
-- Name: date_dimension_date_key_idx; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX date_dimension_date_key_idx ON date_dimension USING btree (date_key);


--
-- Name: jitter_index; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX jitter_index ON spotted_pokemon USING gist (geo_point_jittered);


--
-- Name: latitude_index; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX latitude_index ON spotted_pokemon USING btree (latitude);


--
-- Name: latitude_jit_index; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX latitude_jit_index ON spotted_pokemon USING btree (latitude_jittered);


--
-- Name: longitude_index; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX longitude_index ON spotted_pokemon USING btree (longitude);


--
-- Name: longitude_jit_index; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX longitude_jit_index ON spotted_pokemon USING btree (longitude_jittered);


--
-- Name: name_index; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX name_index ON spotted_pokemon USING btree (name);


--
-- Name: point_index; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX point_index ON spotted_pokemon USING gist (geo_point);


--
-- Name: pokemon_id_index; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX pokemon_id_index ON spotted_pokemon USING btree (pokemon_id);


--
-- Name: time_dimension_time_key_idx; Type: INDEX; Schema: public; Owner: pokemon_go_role
--

CREATE INDEX time_dimension_time_key_idx ON time_dimension USING btree (time_key);


--
-- Name: compute_point; Type: TRIGGER; Schema: public; Owner: pokemon_go_role
--

CREATE TRIGGER compute_point BEFORE INSERT OR UPDATE ON spotted_pokemon FOR EACH ROW EXECUTE PROCEDURE create_point_from_lon_lat();


--
-- Name: compute_point_jittered; Type: TRIGGER; Schema: public; Owner: pokemon_go_role
--

CREATE TRIGGER compute_point_jittered BEFORE INSERT OR UPDATE ON spotted_pokemon FOR EACH ROW EXECUTE PROCEDURE create_point_from_lon_lat_jit();


--
-- Name: create_datekey; Type: TRIGGER; Schema: public; Owner: pokemon_go_role
--

CREATE TRIGGER create_datekey BEFORE INSERT OR UPDATE ON spotted_pokemon FOR EACH ROW EXECUTE PROCEDURE create_datekey_fn();


--
-- Name: create_timekey; Type: TRIGGER; Schema: public; Owner: pokemon_go_role
--

CREATE TRIGGER create_timekey BEFORE INSERT OR UPDATE ON spotted_pokemon FOR EACH ROW EXECUTE PROCEDURE create_timekey_fn();


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

